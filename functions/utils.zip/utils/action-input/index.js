export function parseMapVariables(headers) {
  return headers.reduce(
    (acc, { key, value }) => ({ ...acc, [key]: value }),
    {},
  );
}

export function parseCollection(collection) {
  return collection.data || [];
}

export function parseProperty(property) {
  return property[0];
}
